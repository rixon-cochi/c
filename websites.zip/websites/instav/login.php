<?php
header('Location: https://instagram.com');
exit();

